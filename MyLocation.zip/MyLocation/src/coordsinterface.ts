export interface Coords {
    lat: number;
    lon: number;
}