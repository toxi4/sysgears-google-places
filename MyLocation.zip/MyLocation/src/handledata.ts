import {Coords} from "./coordsinterface";
import {getDataJson} from "./getdatajson";
import {closestPlace} from "./closestplace";
import {printDiv} from "./printdiv";

export function handleData(coord:Coords,radius:number,reduced:boolean,request:Request){
    let test=getDataJson(request);
    let found;
    test.then(function(json) {
        let cycles=0;
        if((json.results.length>=20)&&(cycles<=5)){
            reduced=true;
            let trad=Math.floor(radius/2);
            console.log('reducing radius '+trad);
            request= new Request('https://maps.googleapis.com/maps/api/place/nearbysearch/json?location='+coord.lat+','+coord.lon+'&radius='+trad+'&key=AIzaSyA1taNsuK7wLBs1CfnyA53xwKtlb9JYVFw', { method: 'GET',mode: 'cors'});
            handleData(coord,trad,reduced,request);
        }else if((json.results.length===0)&&(!reduced)){
            printDiv("No Google places nearby","map")
        }else if((json.results.length===0)&&(reduced)){
            cycles++;
            console.log('increasing radius '+(radius+5));
            request= new Request('https://maps.googleapis.com/maps/api/place/nearbysearch/json?location='+coord.lat+','+coord.lon+'&radius='+(radius+5)+'&key=AIzaSyA1taNsuK7wLBs1CfnyA53xwKtlb9JYVFw', { method: 'GET',mode: 'cors'});
            handleData(coord,radius+5,reduced,request);
        }else{
            let chosenPlaces:any[]=[];
            json.results.forEach(function(element:any,i:number){
                chosenPlaces[i]={};
                chosenPlaces[i].name=element["name"];
                chosenPlaces[i].vicinity=element["vicinity"];
                chosenPlaces[i].lat=element["geometry"]["location"].lat;
                chosenPlaces[i].lon=element["geometry"]["location"].lng;
            });
            found=closestPlace(chosenPlaces,radius,coord,10000000);
            printDiv('Looks like you are here:'+found["name"]+' '+found["vicinity"],"map");
        }
    })
}