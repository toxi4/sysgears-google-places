export function readcoords(){
    let lat=parseFloat((<HTMLInputElement>document.getElementById("lat")).value);
    let lon=parseFloat((<HTMLInputElement>document.getElementById("lon")).value);
    return {lat:lat,lon:lon}
};