import {IndexController} from "./indexController";

window.onload=function(){
    let MyIndexController = new IndexController("lat","lon","locate",50);
}


