import {Coords} from "./coordsinterface";
import {handleData} from "./handledata";

export class IndexController{
    lat:string;//latitude
    lon:string;//longitude
    loc:HTMLElement;//button element
    coords:Coords;
    radius:number;
    constructor(lat: string,lon:string,loc:string,rad:number) {
        this.lat = lat;
        this.lon = lon;
        this.loc = document.getElementById(loc);;
        this.coords = this.readCoords();
        this.radius=rad;
        this.loc.addEventListener("click", (e:Event) => this.clicked());
    }
    readCoords(){
        return {lat:parseFloat((<HTMLInputElement>document.getElementById(this.lat)).value),lon:parseFloat((<HTMLInputElement>document.getElementById(this.lon)).value)}
    };
    clicked=function(){
        let coord = this.readCoords();
        let myRequest = new Request('https://maps.googleapis.com/maps/api/place/nearbysearch/json?location='+coord.lat+','+coord.lon+'&radius='+this.radius+'&key=AIzaSyA1taNsuK7wLBs1CfnyA53xwKtlb9JYVFw', { method: 'GET',mode: 'cors'});
        handleData(coord, this.radius, false, myRequest);
    }
}