export function printDiv(s1:string,targetId:string){
    let map=document.getElementById(targetId);
    let div=document.createElement("div");
    let text=document.createTextNode(s1);
    map.appendChild(div);
    div.appendChild(text);
}