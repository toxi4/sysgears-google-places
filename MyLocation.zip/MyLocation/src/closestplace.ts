import {Coords} from "./coordsinterface";

function calculateDistance(x1:number,y1:number,x2:number,y2:number){
    return Math.sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2))
}

export function closestPlace(plasePos:Array<any>,rad:number,yourPos:Coords,multiplier:number){
    console.log(plasePos);
    let min=calculateDistance(yourPos.lat*multiplier,yourPos.lon*multiplier,plasePos[0].lat*multiplier,plasePos[0].lon*multiplier);
    console.log(0+' '+min);
    let minIndex=0;
    for(let i=1;i<plasePos.length;i++){
        let dist=calculateDistance(yourPos.lat*multiplier,yourPos.lon*multiplier,plasePos[i].lat*multiplier,plasePos[i].lon*multiplier);
        console.log(i+' '+dist);
        if (dist<min){
            min=dist;
            minIndex=i;
        }
    }
    return plasePos[minIndex]
}