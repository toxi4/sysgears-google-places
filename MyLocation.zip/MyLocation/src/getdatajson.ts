export function getDataJson(myReq:Request) {
    return fetch(myReq)
        .then(function(response) { return response.json() })
        .catch(function(err) {
            console.log('Fetch Error :-S', err);
        });
}